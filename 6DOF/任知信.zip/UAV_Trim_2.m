function [xtrim, ytrim, utrim, dxtrim] = UAV_Trim_2(V, H, path)
    % [xtrim,utrim]=cktrim(V,H,path)
    % Calculate trim date
    %      1   2      3     4   5   6    7  8  9  10   11     12
    % X = [Vt, alpha, beta, PN, PE, alt, P, Q, R, phi, theta, psi,]
    %      1   2      3     4   5   6    7  8  9  10   11     12   13
    % Y = [Vt, alpha, beta, PN, PE, alt, P, Q, R, phi, theta, psi, theta-alpha]
    % u = [elevator, aileron, rudder, engine]

    x0 = [V; deg2rad(4); 0; 0; 0; H; 0; 0; 0; 0; deg2rad(4+ path); 0];
    IX = [2; 7; 8; 9; 10; 11; 12];

    u0 = [0; 0; 0; 0.3];
    IU = [2; 3];

    y0 = [V; 4; 0; 0; 0; H; 0; 0; 0; 0; 4; 0; path];
    IY = [2; 7; 8; 9; 10; 11; 12; 13];

    dx0 = zeros(12, 1);
    IDX = [1; 2; 3; 7; 8; 9; 10; 11; 12];

    % options = optimset('MaxFunEvals', 2e4, 'TolX', 1e-4, 'TolFun', 1e-4);

    [xtrim, utrim, ytrim, dxtrim] = trim('UAV_Ctrl', x0, u0, y0, IX, IU, IY, dx0, IDX);
